import React, { useState, useEffect, useRef } from "react";
import { motion } from "motion/react";
import {
  Shield,
  Award,
  Cpu,
  ArrowRight,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Building2,
  Users,
  Target,
  Sparkles,
  ChevronRight,
  TrendingUp,
  FileSpreadsheet,
  Activity,
  HeartHandshake,
  MessageSquare
} from "lucide-react";

import {
  COMPANY_NAME,
  COMPANY_FULL_NAME,
  TAGLINE,
  SLOGAN,
  CO_FOUNDER,
  CORE_PILLARS,
  GENERAL_METRICS,
  CORE_VALUES,
  ETHICS_COMMITMENTS,
  GOALS,
  DIVISIONS,
  INNOVATION_DIMENSIONS,
  TEAM_MEMBERS
} from "./data";

// Import modular sub-components
import Header from "./components/Header";
import InteractiveAdviser from "./components/InteractiveAdviser";
import WarRoomShowcase from "./components/WarRoomShowcase";
import CapabilitiesGrid from "./components/CapabilitiesGrid";
import MethodologySlider from "./components/MethodologySlider";
import GlobalMap from "./components/GlobalMap";
import Footer from "./components/Footer";

// New multi-view sub-components
import ServiceDetailPage from "./components/ServiceDetailPage";
import BlogsPage from "./components/BlogsPage";
import CareersPage from "./components/CareersPage";
import TestimonialsShowcase from "./components/TestimonialsShowcase";
import SectionDivider from "./components/SectionDivider";
import AlliancesSection from "./components/AlliancesSection";
import LegalSection from "./components/LegalSection";

export default function App() {
  const [currentView, setCurrentView] = useState<"home" | "blogs" | "careers" | "service-detail">("home");
  const [selectedService, setSelectedService] = useState<{ name: string; category: string } | null>(null);
  const [activeSection, setActiveSection] = useState<string>("hero");
  const [advisorContext, setAdvisorContext] = useState<{ industry: string; issue: string } | null>(null);

  // Contact form state
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    industry: "Manufacturing & Industrial",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Scroll active section observer
  useEffect(() => {
    if (currentView !== "home") return;
    const sections = ["hero", "overview", "team", "alliances", "divisions", "services", "blogs", "careers", "testimonials", "global-presence", "contact", "legal-policies"];
    const handleScroll = () => {
      const scrollPos = window.scrollY + 200;
      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [currentView]);

  const handleNavClick = (sectionId: string) => {
    if (sectionId === "blogs") {
      setCurrentView("blogs");
      setActiveSection("blogs");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    if (sectionId === "careers") {
      setCurrentView("careers");
      setActiveSection("careers");
      window.scrollTo({ top: 0, behavior: "smooth" });
      return;
    }
    
    // For standard home sections
    if (currentView !== "home") {
      setCurrentView("home");
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          element.scrollIntoView({ behavior: "smooth", block: "start" });
          setActiveSection(sectionId);
        } else {
          window.scrollTo({ top: 0, behavior: "smooth" });
          setActiveSection("hero");
        }
      }, 150);
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
        setActiveSection(sectionId);
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
        setActiveSection("hero");
      }
    }
  };

  // Pre-populates contact form based on interactive plan selected
  const handlePlanSelected = (industry: string, contextText: string) => {
    setAdvisorContext({ industry, issue: contextText });
    setFormData((prev) => ({
      ...prev,
      industry: industry,
      message: `Greetings Sidigiqor Team. I ran the Consulting Adviser tool on the website.\n\n[DRAFTED ADVISER DETAILS]:\n${contextText}\n\nWe would like to request an assessment session to review this roadmap and explore how we can optimize our technology footprint.`
    }));
    // Scroll to contact form
    handleNavClick("contact");
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    // Simulate API delivery
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitSuccess(true);
      // Reset form (except message detail if they want to refer to it)
      setFormData({
        name: "",
        email: "",
        phone: "",
        company: "",
        industry: "Manufacturing & Industrial",
        message: ""
      });
      setAdvisorContext(null);
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-300 selection:bg-brand-gold/30 selection:text-white font-sans antialiased">
      {/* Navigation Header */}
      <Header activeSection={activeSection} onNavClick={handleNavClick} />

      {currentView === "home" && (
        <>
          {/* Hero Portal */}
          <section
            id="hero"
            className="relative pt-32 pb-24 md:pt-40 md:pb-32 overflow-hidden bg-black border-b border-white/5"
          >
        {/* Dynamic backdrop radial glow */}
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-20 pointer-events-none">
          <div className="h-full w-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-brand-gold/15 via-transparent to-transparent"></div>
        </div>

        {/* Dynamic backdrop grid lines */}
        <div className="absolute inset-0 pointer-events-none opacity-5 bg-[linear-gradient(to_right,rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:4rem_4rem]" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Hero Texts */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <span className="inline-flex items-center px-3 py-1 rounded-sm text-xs font-mono font-bold bg-brand-gold/10 text-brand-gold border border-brand-gold/20 tracking-wider">
                <Sparkles className="w-3.5 h-3.5 mr-1.5 text-brand-gold animate-pulse" />
                BUILT IN INDIA. SCALING GLOBALLY.
              </span>
              
              <div className="flex items-center gap-2 mb-2">
                <span className="h-[1px] w-8 bg-brand-gold"></span>
                <span className="text-xs text-brand-gold font-bold tracking-[0.2em] uppercase">Leading the Digital Frontier</span>
              </div>

              <h1 className="font-display font-light text-white text-4xl sm:text-5xl lg:text-7xl tracking-tighter leading-none uppercase">
                Architecting <span className="font-medium italic text-brand-gold">Resilient</span> <br />
                Technology Ecosystems.
              </h1>

              <p className="text-gray-400 text-sm sm:text-base leading-relaxed max-w-2xl font-medium">
                Sidigiqor Technologies is an elite, multidisciplinary global technology consulting organization. We architect high-performance digital systems, execute highly rigorous cybersecurity audits (VAPT), deploy advanced secure firewalls, and develop state-of-the-art AI/ML models. With strategic operations across India, the GCC region, Europe, the United Kingdom, and North America, we build and manage resilient technological foundations for leading enterprises and public-sector operations.
              </p>

              {/* Core Pillars quick overview chips */}
              <div className="flex flex-wrap gap-2 pt-2">
                {CORE_PILLARS.map((p, idx) => (
                  <span
                    key={idx}
                    className="inline-flex items-center px-2.5 py-1 rounded-sm text-[10px] font-mono font-bold bg-[#0f0f0f] text-gray-300 border border-white/5 hover:bg-white/5 hover:border-white/10 transition-colors shadow-xs"
                  >
                    <CheckCircle2 className="w-3 h-3 text-brand-gold mr-1.5" />
                    {p}
                  </span>
                ))}
              </div>

              {/* Action row */}
              <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
                <button
                  id="hero-primary-cta"
                  onClick={() => handleNavClick("divisions")}
                  className="bg-brand-gold hover:bg-brand-gold-dark text-black px-6 py-3 rounded-sm text-xs font-bold tracking-widest uppercase inline-flex items-center justify-center transition-all shadow-md group cursor-pointer"
                >
                  Explore Divisions
                  <ArrowRight className="w-3.5 h-3.5 ml-2 transition-transform group-hover:translate-x-1" />
                </button>
                <button
                  id="hero-secondary-cta"
                  onClick={() => handleNavClick("industries")}
                  className="bg-white/5 hover:bg-white/10 text-white border border-white/5 px-6 py-3 rounded-sm text-xs font-bold tracking-widest uppercase inline-flex items-center justify-center transition-all cursor-pointer"
                >
                  Interactive Assessment
                </button>
              </div>
            </div>

            {/* Right Hero Visual Card */}
            <div className="lg:col-span-5 relative">
              <div className="relative mx-auto max-w-md bg-[#0f0f0f] text-gray-300 rounded-sm p-6 sm:p-8 shadow-2xl border border-white/5">
                {/* SVG ambient graphics */}
                <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                  <Shield className="w-40 h-40 text-white" />
                </div>

                <div className="space-y-6">
                  <div>
                    <span className="text-[10px] font-mono tracking-widest text-brand-gold font-bold uppercase">
                      SYSTEM CAPABILITY STATUS
                    </span>
                    <h2 className="font-display font-light text-xl text-white mt-1 uppercase">
                      Technology That Protects. <br />
                      Intelligence That Delivers.
                    </h2>
                  </div>

                  {/* Core highlight metrics in card */}
                  <div className="grid grid-cols-2 gap-4 border-t border-white/5 pt-5">
                    <div>
                      <span className="text-[9px] font-mono text-gray-500 uppercase">Consulting Ethos</span>
                      <span className="text-xs font-bold text-gray-200 block mt-1">Discovery First</span>
                      <span className="text-[10px] text-gray-400 block">Assess before solving</span>
                    </div>
                    <div>
                      <span className="text-[9px] font-mono text-gray-500 uppercase">Security Footprint</span>
                      <span className="text-xs font-bold text-gray-200 block mt-1">Security by Design</span>
                      <span className="text-[10px] text-gray-400 block">Default perimeter hardening</span>
                    </div>
                  </div>

                  <div className="bg-black/40 p-4 rounded-sm border border-white/5">
                    <span className="text-[9px] font-mono text-brand-gold uppercase font-bold block mb-2">
                      Active Geographies
                    </span>
                    <div className="grid grid-cols-2 gap-2 text-xs text-gray-400">
                      <div className="flex items-center">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
                        <span>India HQ (Panchkula)</span>
                      </div>
                      <div className="flex items-center">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
                        <span>GCC (Kuwait/Dubai)</span>
                      </div>
                      <div className="flex items-center col-span-2">
                        <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full mr-2 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
                        <span>Americas Hub (New York)</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-[11px] text-brand-gold font-mono text-center tracking-wider uppercase max-w-xl mx-auto">
                    Securing enterprise perimeters, architecting resilient infrastructure, and powering global digital transformation.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Overview / About Section */}
      <section id="overview" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Main Title Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-10">
            <div className="lg:col-span-5">
              <div className="flex items-center gap-2 mb-3">
                <span className="h-[1px] w-8 bg-brand-gold"></span>
                <span className="text-xs text-brand-gold font-bold tracking-[0.2em] uppercase">01. Corporate Overview</span>
              </div>
              <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight leading-none uppercase">
                About <span className="font-medium italic text-brand-gold">Sidigiqor</span> Technologies.
              </h2>
              <p className="mt-4 text-gray-400 text-sm leading-relaxed font-medium">
                Headquartered in Panchkula, Haryana, India, Sidigiqor is a premier multidisciplinary enterprise consulting firm. We represent a new paradigm in global technology service execution, merging tactical on-the-ground support with highly specialized cloud, VAPT cyber security, and machine learning software engineering.
              </p>
              
              {/* Highlight Box */}
              <div className="mt-6 border-l-2 border-brand-gold bg-[#0f0f0f] pl-4 py-3 pr-2 rounded-sm italic text-xs sm:text-sm text-gray-300 font-medium border-r border-y border-white/5 shadow-xs">
                &ldquo;Rather than operating as a conventional IT services provider, we position ourselves as a long-term technology consulting partner, helping organizations design, implement, secure, and optimize technology ecosystems.&rdquo;
              </div>
            </div>

            <div className="lg:col-span-7 space-y-6 text-gray-400 text-xs sm:text-sm leading-relaxed">
              <p>
                In today&apos;s highly competitive and security-sensitive digital economy, enterprises are constantly challenged to accelerate development, secure multi-cloud perimeters, optimize complex networking topologies, and extract value from data. Sidigiqor was founded to bridge the gap between high-level advisory and hands-on, high-caliber implementation. We operate with a core belief that secure digital perimeters and robust network infrastructure are not optional extras, but fundamental pillars of a resilient, sustainable business strategy.
              </p>
              <p>
                Whether designing a custom zero-trust microsegmentation architecture for a manufacturing group, auditing a banking portal for deep VAPT compliance, compiling bespoke generative AI models, or building specialized offline-first campaign management applications for our Political Consulting Division, Sidigiqor engineers solutions that are meticulously designed, carefully optimized, and backed by institutional-grade support.
              </p>

              {/* General Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4">
                {GENERAL_METRICS.map((metric, idx) => (
                  <div key={idx} className="bg-[#0f0f0f] hover:bg-white/[0.02] transition-colors p-4 rounded-sm border border-white/5 shadow-xs">
                    <span className="font-display font-light text-2xl text-white block">
                      {metric.value}
                    </span>
                    <span className="text-[10px] font-mono text-brand-gold font-bold block mt-1 uppercase tracking-wider">
                      {metric.label}
                    </span>
                    <span className="text-[10px] text-gray-500 block mt-0.5 leading-snug">
                      {metric.description}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Leaders Quote block */}
          <div className="bg-[#0f0f0f] rounded-sm border border-white/5 p-6 sm:p-8 mb-16 hover:bg-white/[0.01] transition-colors shadow-xl">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
              <div className="md:col-span-8 space-y-4">
                <span className="text-[10px] font-mono tracking-widest text-brand-gold font-bold uppercase block">
                  LEADERSHIP PHILOSOPHY
                </span>
                <blockquote className="font-display font-light text-lg sm:text-xl md:text-2xl text-white tracking-tight leading-snug uppercase">
                  &ldquo;Technology Should <span className="font-medium italic text-brand-gold">Simplify</span> Business, Not Complicate It.&rdquo;
                </blockquote>
                <p className="text-xs sm:text-sm text-gray-400 leading-relaxed max-w-2xl font-medium">
                  Every client engagement begins with understanding the business objective, identifying operational challenges, assessing existing environments, and designing solutions that align with long-term strategic goals. This approach enables us to deliver technology that is not only technically sound but also commercially valuable.
                </p>
                <div>
                  <span className="font-display font-bold text-sm text-white block uppercase">
                    {CO_FOUNDER}
                  </span>
                  <span className="text-[10px] font-mono text-gray-500 font-bold block uppercase mt-0.5">
                    Co-Founder, Sidigiqor Technologies
                  </span>
                </div>
              </div>

              {/* Side Stats Info Table */}
              <div className="md:col-span-4 bg-black/40 text-gray-300 rounded-sm p-5 border border-white/5 space-y-4">
                <span className="text-[9px] font-mono tracking-widest text-brand-gold font-bold uppercase block border-b border-white/5 pb-2">
                  Corporate Highlights
                </span>
                <div className="space-y-2.5 text-[11px] font-sans">
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Headquarters</span>
                    <span className="text-white text-right font-semibold">Panchkula, Haryana</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Founders Scope</span>
                    <span className="text-white text-right font-semibold">Consulting & AI Dev</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Legal Status</span>
                    <span className="text-white text-right font-semibold">OPC Private Limited</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500 font-medium">Delivery</span>
                    <span className="text-white text-right font-semibold">On-site / Remote / Hybrid</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Mission & Vision Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
            <div className="bg-[#0f0f0f] hover:bg-white/[0.01] transition-colors rounded-sm border border-white/5 p-6 sm:p-8 space-y-3.5 shadow-xl">
              <div className="p-3 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm inline-block">
                <Target className="w-5 h-5" />
              </div>
              <h3 className="font-display font-light text-lg text-white uppercase">
                Our Corporate Mission
              </h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-medium">
                <strong className="text-white">Simplifying Technology. Securing Businesses. Enabling Growth.</strong> At Sidigiqor, our mission is to help businesses simplify technology management through consulting-led solutions that improve security, scalability, efficiency, and innovation.
              </p>
              <ul className="space-y-2 pt-2 text-xs text-gray-400 font-medium">
                <li className="flex items-center">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full mr-2"></span>
                  Understand business challenges before selecting technology.
                </li>
                <li className="flex items-center">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full mr-2"></span>
                  Deliver measurable business value through practical innovation.
                </li>
              </ul>
            </div>

            <div className="bg-[#0f0f0f] hover:bg-white/[0.01] transition-colors rounded-sm border border-white/5 p-6 sm:p-8 space-y-3.5 shadow-xl">
              <div className="p-3 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm inline-block">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-display font-light text-lg text-white uppercase">
                Our Corporate Vision
              </h3>
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-medium">
                <strong className="text-white">Building a Global Technology Consulting Organization from India.</strong> We believe that Indian engineering talent, combined with disciplined consulting and customer-centric execution, can compete on the global stage. Our ambition is to serve organizations across India, the Gulf, Europe, North America, and Asia-Pacific.
              </p>
              <ul className="space-y-2 pt-2 text-xs text-gray-400 font-medium">
                <li className="flex items-center">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full mr-2"></span>
                  Become trusted advisors who understand long-term priorities.
                </li>
                <li className="flex items-center">
                  <span className="w-1.5 h-1.5 bg-brand-gold rounded-full mr-2"></span>
                  Embed rigorous cybersecurity standards by default.
                </li>
              </ul>
            </div>
          </div>

          {/* Ethics and Core Values Expandable Grid */}
          <div className="space-y-6">
            <div className="text-center max-w-xl mx-auto">
              <h3 className="font-display font-light text-xl sm:text-2xl text-white uppercase">
                Values & Business Ethics
              </h3>
              <p className="mt-1.5 text-gray-500 text-xs sm:text-sm font-medium">
                Sidigiqor operates with confidentiality, transparency, and deep accountability in all professional client relations.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {CORE_VALUES.map((val, idx) => (
                <div key={idx} className="bg-[#0f0f0f] hover:bg-white/[0.01] p-5 rounded-sm border border-white/5 shadow-xl transition-colors">
                  <span className="text-xs font-bold font-mono text-brand-gold">0{idx + 1}</span>
                  <h4 className="font-display font-bold text-sm text-white mt-1 uppercase">
                    {val.title}
                  </h4>
                  <p className="text-gray-400 text-xs mt-2 leading-relaxed font-sans font-medium">
                    {val.description}
                  </p>
                </div>
              ))}
            </div>

            {/* Ethics Commitments Panel */}
            <div className="bg-[#0f0f0f] text-gray-300 rounded-sm p-6 border border-white/5 shadow-xl hover:bg-white/[0.01] transition-colors">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono tracking-widest text-brand-gold font-bold uppercase">
                    TRUSTED PARTNERSHIP
                  </span>
                  <h4 className="font-display font-light text-base text-white uppercase">
                    Our Ethical Compliance Assurances
                  </h4>
                  <p className="text-xs text-gray-500 max-w-xl font-medium">
                    Technology consulting requires organizations to place significant trust in their consulting partners. We protect client databases, intellectual property, and network access under strict protocols.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 shrink-0">
                  {ETHICS_COMMITMENTS.slice(0, 4).map((cmt, idx) => (
                    <div key={idx} className="flex items-center space-x-2 text-gray-300 text-xs font-medium">
                      <CheckCircle2 className="w-4 h-4 text-brand-gold shrink-0" />
                      <span>{cmt}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Corporate Compliance & Certifications Section */}
            <div className="mt-12 pt-12 border-t border-white/5 space-y-8">
              <div className="text-center max-w-xl mx-auto">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <span className="text-[10px] font-mono text-brand-gold font-bold uppercase tracking-wider">Credentials & Governance</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-brand-gold animate-pulse"></span>
                </div>
                <h3 className="font-display font-light text-xl sm:text-2xl text-white uppercase">
                  Institutional Registrations & Standards
                </h3>
                <p className="mt-1.5 text-gray-500 text-xs sm:text-sm font-medium">
                  Sidigiqor's enterprise engineering team and corporate entity align with leading regulatory, governmental, and individual standards.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Company Registrations Card */}
                <div className="bg-[#0f0f0f] p-6 rounded-sm border border-white/5 hover:border-brand-gold/20 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm">
                        <Building2 className="w-4 h-4" />
                      </div>
                      <h4 className="font-display font-bold text-sm text-white uppercase">
                        Company Registrations
                      </h4>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed font-medium">
                      Legally registered and formally authorized corporate entity complying with stringent corporate acts, credit systems, and security guidelines.
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {["Government of India", "Startup India", "MSME", "ISO Certified", "Dun & Bradstreet (D&B)", "NESA"].map((tag, i) => (
                        <span key={i} className="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-mono font-bold bg-white/5 border border-white/5 text-gray-300">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Regulatory Alignment Card */}
                <div className="bg-[#0f0f0f] p-6 rounded-sm border border-white/5 hover:border-brand-gold/20 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm">
                        <Shield className="w-4 h-4" />
                      </div>
                      <h4 className="font-display font-bold text-sm text-white uppercase">
                        Regulatory Compliance
                      </h4>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed font-medium">
                      Strict data safety, secure cloud-hosting protocols, and complete compliance alignment for handling confidential public-sector and enterprise resources.
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {["GDPR Compliant", "Privacy Shield", "Confidentiality Handshake", "Zero Leak Policy"].map((tag, i) => (
                        <span key={i} className="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-mono font-bold bg-brand-gold/10 border border-brand-gold/20 text-brand-gold">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Professional Certifications Card */}
                <div className="bg-[#0f0f0f] p-6 rounded-sm border border-white/5 hover:border-brand-gold/20 transition-all duration-300 shadow-xl flex flex-col justify-between">
                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm">
                        <Award className="w-4 h-4" />
                      </div>
                      <h4 className="font-display font-bold text-sm text-white uppercase">
                        Professional Credentials
                      </h4>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed font-medium">
                      Our engineering and advisory team maintains active world-class certifications in cybersecurity, network topology, and governance.
                    </p>
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {["OSCP", "CISSP", "CCIE", "CCNP", "ITIL", "PMP"].map((tag, i) => (
                        <span key={i} className="inline-flex items-center px-2 py-0.5 rounded-xs text-[10px] font-mono font-bold bg-white/5 border border-white/5 text-gray-300">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* Corporate Leadership & Global Team Section */}
      <section id="team" className="py-12 bg-[#0a0a0a] border-b border-white/5 relative overflow-hidden">
        {/* Decorative subtle background grid */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:3rem_3rem] opacity-100 pointer-events-none"></div>
        
        {/* Radial highlight spot */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-radial from-brand-gold/5 via-transparent to-transparent pointer-events-none"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-col items-center mb-10 max-w-3xl mx-auto text-center">
            <div className="flex items-center gap-2 mb-3">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-xs text-brand-gold font-bold tracking-[0.2em] uppercase">01b. Our Corporate Brain Trust</span>
            </div>
            <h2 className="font-display font-light text-3xl sm:text-4xl lg:text-5xl text-white tracking-tight uppercase leading-tight">
              MEET THE <span className="font-medium italic text-brand-gold">EXPERTS</span> & ADVISORS
            </h2>
            <p className="mt-4 text-gray-400 text-sm sm:text-base max-w-xl mx-auto font-medium leading-relaxed">
              Our multidisciplinary brain trust brings together elite cybersecurity consultants, artificial intelligence developers, digital transformation strategists, and seasoned campaign analysts.
            </p>
          </div>

          {/* Redesigned Departmental Segments */}
          <div className="space-y-16">
            {[
              {
                id: "exec",
                title: "Executive Leadership",
                tagline: "Corporate governance and strategic expansion steering global operations.",
                match: (m: any) => m.department === "Executive Leadership"
              },
              {
                id: "growth",
                title: "International Business & Growth",
                tagline: "Drives international business expansion, strategic partnerships, and global client acquisition.",
                match: (m: any) => m.department === "International Business & Growth"
              },
              {
                id: "eng",
                title: "Engineering & Technology",
                tagline: "Pioneering machine learning developments, predictive systems, and institutional-grade cloud systems.",
                match: (m: any) => m.department === "Engineering & Technology"
              },
              {
                id: "sec",
                title: "Cyber Security & AI Consulting",
                tagline: "Provides strategic cybersecurity firewalls, offensive security audits, VAPT, and smart surveillance.",
                match: (m: any) => m.department === "Cyber Security & AI Consulting"
              },
              {
                id: "digi",
                title: "Digital Engineering",
                tagline: "Crafting scalable custom enterprise applications, portals, CRM systems, and digital architectures.",
                match: (m: any) => m.department === "Digital Engineering"
              },
              {
                id: "ops",
                title: "Operations & Customer Success",
                tagline: "Ensuring flawless operational scaling, continuous relationship management, and generative search visibility.",
                match: (m: any) => m.department === "Customer Success" || m.department === "Human Resources" || m.department === "Digital Marketing"
              },
              {
                id: "pol",
                title: "Political Consulting Division",
                tagline: "Structuring custom campaign management war rooms, Booth Android applications, and strategic analytics.",
                match: (m: any) => m.department === "Political Consulting Division"
              }
            ].map((dept, deptIdx) => {
              const members = TEAM_MEMBERS.filter(dept.match);
              if (members.length === 0) return null;

              return (
                <div key={dept.id} className="space-y-6">
                  {/* Department Header */}
                  <div className="border-b border-white/5 pb-4 flex flex-col md:flex-row md:items-end justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono text-brand-gold font-bold">0{deptIdx + 1} // DEPT</span>
                        <span className="w-1.5 h-1.5 rounded-full bg-brand-gold animate-pulse"></span>
                      </div>
                      <h3 className="font-display font-medium text-lg sm:text-xl text-white tracking-wide uppercase mt-1">
                        {dept.title}
                      </h3>
                    </div>
                    <p className="text-xs text-gray-500 max-w-md font-medium md:text-right">
                      {dept.tagline}
                    </p>
                  </div>

                  {/* Department Grid */}
                  <div className={`grid grid-cols-1 ${members.length === 1 ? "md:grid-cols-1 max-w-2xl" : members.length === 2 ? "md:grid-cols-2" : "md:grid-cols-2 lg:grid-cols-3"} gap-6`}>
                    {members.map((member, idx) => (
                      <div 
                        key={idx} 
                        className="bg-[#0f0f0f] border border-white/5 hover:border-brand-gold/30 hover:bg-[#141414] rounded-sm p-6 flex flex-col justify-between transition-all duration-300 relative group shadow-xl"
                      >
                        <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-brand-gold/0 via-brand-gold/30 to-brand-gold/0 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        
                        <div className="space-y-4">
                          <div className="flex items-start justify-between border-b border-white/5 pb-3">
                            <div>
                              <h4 className="font-display font-medium text-base text-white group-hover:text-brand-gold transition-colors uppercase">
                                {member.name}
                              </h4>
                              <p className="text-xs text-brand-gold font-mono font-bold mt-1">
                                {member.role}
                              </p>
                            </div>
                            <span className="text-[9px] font-mono text-gray-500 font-bold uppercase tracking-wider bg-white/5 px-2 py-0.5 rounded-xs">
                              ACTIVE
                            </span>
                          </div>
                          
                          {member.bio && (
                            <p className="text-xs text-gray-400 leading-relaxed font-medium font-sans italic">
                              &ldquo;{member.bio}&rdquo;
                            </p>
                          )}
                        </div>

                        <div className="flex items-center gap-2 pt-6 mt-4 border-t border-white/5 text-[9px] font-mono text-gray-500 font-bold uppercase">
                          <MapPin className="w-3 h-3 text-brand-gold/60" />
                          <span>Global Operations Portfolio</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <SectionDivider />

      <AlliancesSection />

      <SectionDivider />

      {/* Strategic Business Divisions */}
      <section id="divisions" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center mb-10 max-w-2xl mx-auto text-center">
            <div className="flex items-center gap-2 mb-3">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-xs text-brand-gold font-bold tracking-[0.2em] uppercase">02. Strategic Deployments</span>
            </div>
            <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight uppercase">
              Three Core Business Divisions
            </h2>
            <p className="mt-2 text-gray-500 text-sm max-w-lg mx-auto font-medium">
              Our service portfolio is organized into three distinct operational pillars designed around specific local and global markets.
            </p>
          </div>

          {/* Division Card Bento Block Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {DIVISIONS.map((div, idx) => {
              return (
                <div
                  key={div.id}
                  className="bg-[#0f0f0f] border border-white/5 rounded-sm p-6 flex flex-col justify-between hover:bg-white/[0.01] hover:border-brand-gold/20 transition-all duration-300 relative overflow-hidden group shadow-xl"
                >
                  <div className="space-y-5">
                    {/* Header info */}
                    <div className="flex items-center justify-between">
                      <div className="p-3 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-sm">
                        {div.iconName === "Shield" && <Shield className="w-5 h-5" />}
                        {div.iconName === "Vote" && <Award className="w-5 h-5" />}
                        {div.iconName === "Cpu" && <Cpu className="w-5 h-5" />}
                      </div>
                      <span className="text-[10px] font-mono text-gray-500 font-bold uppercase">
                        Division 0{idx + 1}
                      </span>
                    </div>

                    <div>
                      <span className="text-[10px] font-mono text-brand-gold font-bold uppercase tracking-widest block">
                        {div.tagline}
                      </span>
                      <h3 className="font-display font-light text-xl text-white mt-1 leading-snug uppercase">
                        {div.title}
                      </h3>
                      <span className="text-xs font-sans text-gray-400 font-medium block mt-0.5">
                        {div.subtitle}
                      </span>
                    </div>

                    <p className="text-gray-400 text-xs leading-relaxed font-sans font-medium">
                      {div.description}
                    </p>

                    {/* Division core bullets */}
                    <div className="border-t border-white/5 pt-4">
                      <span className="text-[9px] font-mono text-gray-500 uppercase font-bold block mb-2.5">
                        Core Service Scope:
                      </span>
                      <ul className="space-y-2">
                        {div.points.slice(0, 4).map((pt, pIdx) => (
                          <li key={pIdx} className="flex items-start text-xs font-sans text-gray-400 font-medium">
                            <CheckCircle2 className="w-4 h-4 text-brand-gold shrink-0 mr-2.5 mt-0.5" />
                            <span className="leading-normal font-medium">{pt}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Footer details: serving markets */}
                  <div className="mt-8 pt-4 border-t border-white/5 space-y-2.5">
                    <div>
                      <span className="text-[8px] font-mono text-gray-500 uppercase font-bold block">
                        Key Markets Served:
                      </span>
                      <div className="flex flex-wrap gap-1 mt-1.5">
                        {div.markets.slice(0, 4).map((m, mIdx) => (
                          <span
                            key={mIdx}
                            className="inline-block px-2 py-0.5 rounded-sm bg-[#0a0a0a] border border-white/5 text-[9px] text-gray-400 font-mono"
                          >
                            {m}
                          </span>
                        ))}
                        {div.markets.length > 4 && (
                          <span className="inline-block px-2 py-0.5 rounded-sm bg-black text-[9px] text-gray-500 font-mono">
                            +{div.markets.length - 4} More
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => handleNavClick("services")}
                      className="w-full bg-brand-gold hover:bg-brand-gold-dark text-black rounded-sm text-center py-2 text-xs font-bold tracking-widest uppercase transition-all shadow-xl cursor-pointer"
                    >
                      Browse Scope
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* Services Showcase Section */}
      <section id="services" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center mb-10 max-w-2xl mx-auto text-center">
            <div className="flex items-center gap-2 mb-3">
              <span className="h-[1px] w-8 bg-brand-gold"></span>
              <span className="text-xs text-brand-gold font-bold tracking-[0.2em] uppercase">03. Core Portfolio</span>
            </div>
            <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight uppercase">
              Technology Capabilities
            </h2>
            <p className="mt-2 text-gray-400 text-sm max-w-lg mx-auto font-medium">
              Our multidisciplinary engineering teams design custom software, implement secure networks, and deploy intelligent vision systems.
            </p>
          </div>

          {/* Render Interactive Services Grid */}
          <CapabilitiesGrid
            onServiceClick={(name, category) => {
              setSelectedService({ name, category });
              setCurrentView("service-detail");
            }}
          />
        </div>
      </section>

      <SectionDivider />

      {/* Consulting Methodology & Innovation Framework */}
      <section id="methodology" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-10">
            <div className="lg:col-span-5">
              <span className="text-[10px] font-mono font-bold tracking-widest text-brand-gold uppercase block mb-3">
                04. METHODOLOGY & FRAMEWORK
              </span>
              <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight leading-tight uppercase">
                Our Consulting Model
              </h2>
              <p className="mt-4 text-gray-400 text-sm leading-relaxed font-medium">
                We believe that successful technology transformations require rigorous structural discovery. We don&apos;t sell isolate software—we formulate business capabilities.
              </p>
            </div>

            <div className="lg:col-span-7">
              <p className="text-gray-400 text-xs sm:text-sm leading-relaxed font-medium">
                Sidigiqor follows an outcome-driven delivery roadmap spanning discover, assess, design, implement, secure, and support. This structured lifecycle minimizes deployment risk, ensures strict compliance, and creates sustainable competitive advantage.
              </p>
            </div>
          </div>

          {/* Methodology Step-by-Step Interactive Slider */}
          <MethodologySlider />

          {/* Innovation Framework Display */}
          <div className="mt-20 border-t border-white/5 pt-16">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-[10px] font-mono font-bold tracking-widest text-brand-gold uppercase block mb-3">
                INNOVATION WITH PURPOSE
              </span>
              <h3 className="font-display font-light text-2xl text-white tracking-tight uppercase">
                Our Innovation Evaluation Matrix
              </h3>
              <p className="mt-2 text-gray-500 text-xs sm:text-sm max-w-lg mx-auto font-medium">
                Emerging tools (AI, ML, IoT, Blockchain) are evaluated through four specific pillars before we suggest them in our design blueprints.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {INNOVATION_DIMENSIONS.map((dim, idx) => (
                <div
                  key={idx}
                  className="bg-[#0f0f0f] rounded-sm border border-white/5 p-5 flex flex-col justify-between hover:bg-white/[0.01] transition-colors shadow-xl"
                >
                  <div className="space-y-3">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-sm bg-brand-gold/10 border border-brand-gold/20 text-[10px] font-mono font-bold text-brand-gold uppercase">
                      Pillar 0{idx + 1}
                    </span>
                    <h4 className="font-display font-bold text-base text-white uppercase">
                      {dim.label}
                    </h4>
                    <p className="text-xs text-gray-500 font-mono italic">
                      &ldquo;{dim.question}&rdquo;
                    </p>
                    <p className="text-[11px] sm:text-xs text-gray-400 leading-relaxed font-sans font-medium">
                      {dim.details}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <SectionDivider />

      {/* Industries & Interactive Client Adviser */}
      <section id="industries" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-[10px] font-mono font-bold tracking-widest text-brand-gold uppercase block mb-3">
              05. CLIENT SEGMENTS
            </span>
            <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight uppercase">
              Sectors We Empower
            </h2>
            <p className="mt-2 text-gray-400 text-sm max-w-lg mx-auto font-medium">
              From large-scale industrial manufacturing and healthcare facilities to Indian domestic political campaigns.
            </p>
          </div>

          {/* Interactive Adviser Wizard Component */}
          <InteractiveAdviser onPlanSelected={handlePlanSelected} />

          {/* Political War Room Live Simulation */}
          <div className="mt-12 border-t border-white/5 pt-10">
            <div className="max-w-2xl mx-auto text-center mb-6">
              <span className="text-[10px] font-mono tracking-widest text-brand-gold font-bold uppercase block">
                SPECIAL OPERATIONS SPOTLIGHT
              </span>
              <h3 className="font-display font-light text-2xl text-white tracking-tight mt-1.5 uppercase">
                Indian Political Campaign Management
              </h3>
              <p className="mt-2 text-gray-400 text-xs sm:text-sm font-medium">
                Sidigiqor operates a high-intensity, data-driven political operations division across India, managing campaign CRMs, constituency surveys, and multi-feed command war rooms.
              </p>
            </div>

            {/* War Room Simulator Dashboard */}
            <WarRoomShowcase />
          </div>
        </div>
      </section>

      {/* Client Testimonials and Success Showcase */}
      <TestimonialsShowcase />

      {/* Global Presence Section */}
      <section id="global-presence" className="py-12 bg-[#0a0a0a] border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-[10px] font-mono font-bold tracking-widest text-brand-gold uppercase block mb-3">
              07. GLOBAL ADVISORY
            </span>
            <h2 className="font-display font-light text-3xl sm:text-4xl text-white tracking-tight uppercase">
              International Delivery Locations
            </h2>
            <p className="mt-2 text-gray-500 text-sm max-w-lg mx-auto font-medium">
              Operating administrative engineering terminals and strategic advisory hubs globally.
            </p>
          </div>

          {/* Global Presence Map Component */}
          <GlobalMap />
        </div>
      </section>

      {/* Contact Matrix Form & Details */}
      <section id="contact" className="py-12 bg-[#0a0a0a] border-t border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            
            {/* Left Column: Direct contact info */}
            <div className="lg:col-span-5 space-y-6">
              <div>
                <span className="text-[10px] font-mono font-bold tracking-widest text-brand-gold uppercase block mb-3">
                  08. STRATEGIC CONVERSATION
                </span>
                <h2 className="font-display font-light text-3xl text-white tracking-tight leading-tight uppercase">
                  Reach Our Advisory Team
                </h2>
                <p className="mt-3 text-gray-400 text-xs sm:text-sm leading-relaxed font-medium">
                  Every successful transformation begins with an open conversation. Contact our regional engineers or submit a specific inquiry to schedule a gap-assessment.
                </p>
              </div>

              {/* Direct channels links card */}
              <div className="bg-[#0f0f0f] border border-white/5 rounded-sm p-6 space-y-4 shadow-xl">
                <span className="text-[9px] font-mono tracking-widest text-brand-gold font-bold uppercase block mb-1">
                  Inbound Comms Matrix
                </span>

                <div className="flex items-start space-x-3 text-xs text-gray-300">
                  <Mail className="w-5 h-5 text-brand-gold shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Lead Consultants Direct:</strong>
                    <a href="mailto:Sahil@Sidigiqor.com" className="text-brand-gold hover:underline block font-semibold mt-1">
                      Sahil@Sidigiqor.com
                    </a>
                    <a href="mailto:sidigiqor@gmail.com" className="text-brand-gold hover:underline block">
                      sidigiqor@gmail.com
                    </a>
                  </div>
                </div>

                <div id="whatsapp-comms" className="flex items-start space-x-3 text-xs border-t border-white/5 pt-4 transition-all duration-500 rounded p-2">
                  <div className="p-1.5 rounded-sm bg-emerald-500/10 text-emerald-400 shrink-0 mt-0.5">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <strong className="text-white block">WhatsApp Direct Chat:</strong>
                    <a
                      href="https://wa.me/919911539101?text=Hello!%20I%20am%20interested%20in%20your%20services%20and%20solutions."
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-emerald-600 hover:underline block font-semibold mt-1"
                    >
                      +91 99115 39101 (Click to Chat)
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-xs border-t border-white/5 pt-4 text-gray-300">
                  <Phone className="w-5 h-5 text-brand-gold shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Phone Coordinates:</strong>
                    <a href="tel:+919911539101" className="text-gray-300 block font-semibold hover:underline mt-1">
                      +91 99115 39101 (India HQ)
                    </a>
                    <a href="tel:+971562409703" className="text-gray-300 block hover:underline">
                      +971 56 240 9703 (Gulf Region)
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-3 text-xs border-t border-white/5 pt-4 text-gray-300">
                  <MapPin className="w-5 h-5 text-brand-gold shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-white block">Primary India HQ Address:</strong>
                    <span className="text-gray-400 block leading-relaxed mt-1">
                      Ramgarh, Panchkula, Haryana – 134118 (India)
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-[#0f0f0f] text-gray-300 rounded-sm p-5 text-xs space-y-2 border border-white/5 shadow-xl">
                <span className="text-[9px] font-mono tracking-widest text-brand-gold font-bold uppercase block">
                  Our Uncompromising Promise
                </span>
                <p className="text-gray-400 leading-relaxed font-sans font-medium">
                  &ldquo;We don&apos;t simply implement technology. We build secure, scalable, and future-ready technology ecosystems that empower businesses to grow with confidence.&rdquo;
                </p>
              </div>
            </div>

            {/* Right Column: Inquiry Submission form */}
            <div className="lg:col-span-7 bg-[#0f0f0f] rounded-sm border border-white/5 p-6 sm:p-8 shadow-xl">
              <div className="border-b border-white/5 pb-4 mb-6">
                <span className="text-[9px] font-mono tracking-widest text-brand-gold font-bold uppercase">
                  LEAD INTAKE SYSTEM
                </span>
                <h3 className="font-display font-light text-lg text-white mt-1 uppercase">
                  Corporate Engagement Request
                </h3>
                <p className="text-xs text-gray-500 mt-1 leading-normal font-medium">
                  Submit this brief dossier. A regional technical lead will follow up with schedule availability within 24 business hours.
                </p>
              </div>

              {submitSuccess ? (
                <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-6 rounded-sm space-y-4 text-center animate-fadeIn">
                  <div className="w-12 h-12 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 mx-auto">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <h4 className="font-display font-light text-base text-slate-900">
                      Corporate Briefing Scheduled!
                    </h4>
                    <p className="text-xs text-slate-600 leading-normal max-w-md mx-auto">
                      Thank you for submitting your inquiry. An advisory partner representing Sidigiqor Technologies has successfully received your scenario parameters and will coordinate with you shortly.
                    </p>
                  </div>
                  <button
                    onClick={() => setSubmitSuccess(false)}
                    className="text-xs font-semibold text-amber-600 hover:text-amber-700 underline"
                  >
                    Submit Another Request
                  </button>
                </div>
              ) : (
                <form onSubmit={handleFormSubmit} className="space-y-4.5 text-slate-700">
                  {advisorContext && (
                    <div className="bg-amber-500/10 border border-amber-500/20 text-amber-800 px-4 py-3 rounded-sm text-xs flex items-start gap-2.5 animate-fadeIn">
                      <Sparkles className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                      <div>
                        <strong>Interactive Advisor Context Connected:</strong>
                        <p className="text-[11px] text-slate-500 mt-1">
                          The inquiry form is loaded with your tailored {advisorContext.industry} roadmap. You may adjust the details below before submitting.
                        </p>
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                        Contact Name *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        placeholder="e.g. Sahil Rana"
                        className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all bg-black/40 text-white placeholder-gray-500 font-sans font-medium"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                        Work Email *
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        placeholder="e.g. Sahil@Sidigiqor.com"
                        className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all bg-black/40 text-white placeholder-gray-500 font-sans font-medium"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                        Phone Coordinates *
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        placeholder="e.g. +91 99115 39101"
                        className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all bg-black/40 text-white placeholder-gray-500 font-sans font-medium"
                      />
                    </div>

                    <div className="space-y-1.5">
                      <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                        Organization Name
                      </label>
                      <input
                        type="text"
                        value={formData.company}
                        onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                        placeholder="e.g. Sidigiqor Technologies Ltd"
                        className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all bg-black/40 text-white placeholder-gray-500 font-sans font-medium"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                      Primary Industry / Vertical
                    </label>
                    <select
                      value={formData.industry}
                      onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold bg-[#0a0a0a] text-white transition-all font-sans font-medium"
                    >
                      <option value="Manufacturing & Industrial">Manufacturing & Industrial</option>
                      <option value="Healthcare & Clinics">Healthcare & Clinics</option>
                      <option value="Political Campaigns & Groups">Political Campaigns & Groups</option>
                      <option value="Warehousing & Logistics">Warehousing & Logistics</option>
                      <option value="Education & Large Campuses">Education & Large Campuses</option>
                      <option value="Startups & Scaleups">Startups & Scaleups</option>
                      <option value="Other Corporate Sector">Other Corporate Sector</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="block text-xs font-mono font-bold uppercase tracking-wider text-gray-400">
                      Project Parameters & Objective Brief *
                    </label>
                    <textarea
                      required
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      placeholder="Please details your network scope, cybersecurity challenges, firewall configurations, or political campaign timelines..."
                      className="w-full px-3.5 py-2.5 rounded-sm border border-white/10 text-xs focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold transition-all bg-black/40 text-white placeholder-gray-500 font-sans font-medium"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-brand-gold hover:bg-brand-gold-dark text-black font-bold tracking-widest text-xs uppercase py-3 rounded-sm transition-all inline-flex justify-center items-center gap-2 cursor-pointer shadow-xl"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-4 h-4 border-2 border-black/40 border-t-black rounded-full animate-spin"></span>
                        Dispatching Brief...
                      </>
                    ) : (
                      <>
                        Request Gap-Assessment Briefing
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      <SectionDivider />

      <LegalSection />
      </>
      )}

      {currentView === "blogs" && (
        <BlogsPage
          onReadArticle={() => {}}
          onConsult={() => {
            setCurrentView("home");
            setTimeout(() => {
              handleNavClick("contact");
            }, 100);
          }}
        />
      )}

      {currentView === "careers" && (
        <CareersPage
          onConsult={() => {
            setCurrentView("home");
            setTimeout(() => {
              handleNavClick("contact");
            }, 100);
          }}
        />
      )}

      {currentView === "service-detail" && selectedService && (
        <ServiceDetailPage
          serviceName={selectedService.name}
          categoryName={selectedService.category}
          onBack={() => {
            setCurrentView("home");
            setTimeout(() => {
              handleNavClick("services");
            }, 100);
          }}
          onServiceSelect={(name, category) => {
            setSelectedService({ name, category });
            window.scrollTo({ top: 0, behavior: "instant" });
          }}
          onConsult={(srvName) => {
            setFormData((prev) => ({
              ...prev,
              message: `Greetings Sidigiqor Team. We are interested in scheduling a professional gap-assessment briefing for: "${srvName}".\n\nPlease organize a strategy session with Sahil Rana or senior staff.`
            }));
            setCurrentView("home");
            setTimeout(() => {
              handleNavClick("contact");
            }, 100);
          }}
        />
      )}

      {/* Footer component */}
      <Footer onNavClick={handleNavClick} />

      {/* Fixed Quick Help Chat Bubble */}
      <motion.a
        href="https://wa.me/919911539101?text=Hello!%20I%20am%20interested%20in%20your%20services%20and%20solutions."
        target="_blank"
        rel="noopener noreferrer"
        initial={{ opacity: 0, scale: 0.8, y: 50 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ delay: 1, type: "spring", stiffness: 260, damping: 20 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        className="fixed bottom-6 right-6 z-50 flex items-center justify-center w-12 h-12 bg-[#0a0a0a] border border-brand-gold/80 hover:border-brand-gold hover:bg-brand-gold rounded-full shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:shadow-[0_0_25px_rgba(212,175,55,0.6)] transition-all duration-300 group cursor-pointer"
        aria-label="Quick Help Contact"
      >
        <span className="absolute -top-1 -right-1 flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-gold opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-gold"></span>
        </span>
        <MessageSquare className="w-5 h-5 text-brand-gold group-hover:text-black transition-colors duration-300" />
      </motion.a>
    </div>
  );
}
