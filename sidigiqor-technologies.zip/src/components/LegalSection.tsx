import React, { useState } from "react";
import { 
  Scale, 
  FileText, 
  ShieldCheck, 
  Truck, 
  RefreshCw, 
  X, 
  CheckCircle2, 
  FileCheck2,
  ExternalLink,
  ShieldAlert,
  Info
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface PolicyContent {
  id: string;
  title: string;
  icon: React.ComponentType<any>;
  shortDesc: string;
  lastUpdated: string;
  sections: {
    heading: string;
    content: string | string[];
  }[];
}

export default function LegalSection() {
  const [activePolicyId, setActivePolicyId] = useState<string | null>(null);

  const policies: PolicyContent[] = [
    {
      id: "terms",
      title: "Terms and Conditions",
      icon: FileText,
      shortDesc: "Rules, obligations, and service delivery frameworks governing Sidigiqor Technologies client contracts, consulting projects, and software intellectual property.",
      lastUpdated: "July 12, 2026",
      sections: [
        {
          heading: "1. Acceptance of Terms",
          content: "Welcome to Sidigiqor Technologies OPC Private Limited ('Sidigiqor', 'we', 'our', or 'us'). By accessing our website, purchasing our services, signing Annual Maintenance Contracts (AMC), or utilizing our consulting products, you agree to be bound by these Terms and Conditions. If you do not agree, please do not use our services or platforms."
        },
        {
          heading: "2. Scope of Services",
          content: [
            "IT & Enterprise Infrastructure: We offer hardware provisioning, server installation, and computer Annual Maintenance Contracts (AMC) to optimize operational uptime.",
            "Cybersecurity & VAPT: Our team delivers rigorous Vulnerability Assessment and Penetration Testing (VAPT), firewall perimeter deployments, and active threat containment blueprints.",
            "Digital Engineering: We develop bespoke custom software systems, premium web portals, and native or cross-platform mobile apps (iOS & Android).",
            "Artificial Intelligence & Surveillance: We design and deploy smart edge video analytics, AI surveillance cameras, machine learning predictive models, and Generative Engine Optimization (GEO) strategies.",
            "Political Campaigns: We engineer secure constituency databases, offline-first mobile booth applications, and live campaign war room solutions."
          ]
        },
        {
          heading: "3. Service Delivery & Client Obligations",
          content: "For custom digital projects, execution schedules and delivery milestones are governed by individual Statement of Work (SOW) documents. The client must cooperate fully, providing necessary database access, system credentials, and operational feedback in a timely manner. Delays in providing credentials may result in proportional shifts in milestone delivery dates."
        },
        {
          heading: "4. Annual Maintenance Contracts (AMC) Terms",
          content: "AMC contracts for hardware, computers, and server nodes are signed for a minimum duration of twelve (12) months unless agreed otherwise. Scheduled diagnostic checks, preventative physical cleaning, and software patch monitoring will occur according to the agreed SLA. Routine AMC visits do not cover hardware replacements due to physical damage, lightning strikes, or unauthorized third-party tampering."
        },
        {
          heading: "5. Intellectual Property Rights",
          content: "Unless specifically stated in a separate written agreement or SOW, all custom software, bespoke source code repositories, databases, and assets developed specifically for the client shall be transferred 100% to the client upon full payment. Sidigiqor retains ownership of its pre-existing proprietary libraries, frameworks, methodologies, and general toolsets."
        },
        {
          heading: "6. Limitation of Liability",
          content: "Sidigiqor Technologies shall not be liable for any indirect, incidental, consequential, special, or exemplary damages, including but not limited to loss of revenue, profits, data, or operational downtime resulting from system breaches, network outages, or hardware wear, even if advised of the possibility of such damages. Our maximum liability is capped at the fees paid to us under the specific active contract or milestone."
        },
        {
          heading: "7. Governing Law & Dispute Resolution",
          content: "These terms and all contracts are governed by and construed in accordance with the laws of India. Any disputes arising out of these terms shall be subject to the exclusive jurisdiction of the competent courts located in Panchkula, Haryana, India."
        },
        {
          heading: "8. Contact & Legal Address",
          content: "Sidigiqor Technologies OPC Private Limited, Ramgarh, Panchkula, Haryana - 134118, India. Official Corporate Email: Sahil@Sidigiqor.com | Backup: sidigiqor@gmail.com."
        }
      ]
    },
    {
      id: "privacy",
      title: "Privacy Policy",
      icon: ShieldCheck,
      shortDesc: "How we collect, secure, process, and protect your enterprise data, user credentials, client databases, and digital information across our systems.",
      lastUpdated: "July 12, 2026",
      sections: [
        {
          heading: "1. Commitment to Data Privacy",
          content: "At Sidigiqor Technologies, we take the confidentiality of your personal, financial, and proprietary business information very seriously. This Privacy Policy describes how we collect, store, process, and safeguard data when you interact with our consulting services, custom websites, CRM platforms, HRMS portals, or campaign applications."
        },
        {
          heading: "2. Information We Collect",
          content: [
            "Client Contact Data: Names, business email addresses, telephone numbers, and corporate physical locations.",
            "Technical Infrastructure Data: Network IP addresses, firewall log structures, server configuration files, and VAPT target listings provided for diagnostic audits.",
            "Operational Data: Employee attendance records (for custom HRMS integrations), customer lead information (for bespoke CRM deployments), and localized voter demographics (for campaign analytical portals).",
            "Payment Data: Billing addresses, GST numbers, and payment gateway transaction references. We do not store full credit card numbers; payment processing is handled securely by certified third-party gateways."
          ]
        },
        {
          heading: "3. How We Use Your Data",
          content: "We use the collected information solely to perform our contractual duties, optimize networking setups, deliver secure software solutions, respond to support tickets, process milestone payments, and provide cybersecurity alerts. We never sell, lease, rent, or trade your corporate or consumer data with third parties."
        },
        {
          heading: "4. Database Isolation & Cybersecurity",
          content: "All client databases, custom software workloads, and campaign analytics run inside physically isolated Virtual Private Clouds (VPC). We employ end-to-end encryption (AES-256 for data-at-rest and TLS 1.3 for data-in-transit), secure Multi-Factor Authentication (MFA), and automated routine security patching to prevent unauthorized access."
        },
        {
          heading: "5. Compliance with Global Standards",
          content: "We design and deploy digital architectures that support client compliance with GDPR, regional GCC digital protection frameworks, and Indian digital data protection (DPDP) acts. If you require specialized data residency constraints (e.g. hosting databases purely within Kuwait or the UAE), we configure cloud boundaries accordingly."
        },
        {
          heading: "6. User Rights & Data Deletion",
          content: "You have the right to inspect, correct, update, or request the permanent deletion of your personal data stored on our servers. Requests should be emailed directly to Sahil@Sidigiqor.com. We process compliant requests within 10 business days, subject to regulatory tax and record-keeping laws."
        }
      ]
    },
    {
      id: "shipping",
      title: "Shipping & Delivery Policy",
      icon: Truck,
      shortDesc: "Timelines, transport logistics, on-site hardware deployment procedures, and service delivery schedules for physical servers, network firewalls, and AI surveillance kits.",
      lastUpdated: "July 12, 2026",
      sections: [
        {
          heading: "1. Scope of Physical Goods & Deployments",
          content: "Sidigiqor Technologies provides both physical hardware (such as next-generation firewall appliances, enterprise network switches, high-definition CCTV dome cameras, industrial edge computing clusters, NVR servers, and employee biometric gates) and digital delivery of software code bases."
        },
        {
          heading: "2. Hardware Shipping Timelines",
          content: [
            "Domestic Deliveries (India): Physical hardware components are shipped from our technical distribution hubs within 2-4 business days. Delivery to site locations (including Punjab, Haryana, Himachal Pradesh, Chandigarh, Mohali, Panchkula, and nationwide) generally takes 3-7 business days.",
            "International Deliveries (GCC & Global): Hardware shipped to our international client offices (Kuwait, UAE, etc.) takes 7-14 business days, depending on customs clearance procedures and global transit lanes."
          ]
        },
        {
          heading: "3. On-Site Installation and AMC Setup",
          content: "Physical hardware delivery is accompanied by scheduled on-site engineering deployments. For Annual Maintenance Contracts (AMC) and complex security setups, our technicians coordinate on-site arrivals within 48 hours of hardware delivery to begin physical wiring, structural mounting, and network configuration."
        },
        {
          heading: "4. Shipping Costs & Import Tariffs",
          content: "Shipping costs are detailed transparently on project invoices or individual quotation proposals. For international deliveries, the client is responsible for standard regional customs duties, tariffs, and taxes unless specified otherwise in the written corporate agreement."
        },
        {
          heading: "5. Digital Software Delivery",
          content: "All custom websites, bespoke enterprise software, mobile apps, CRM systems, and database configurations are delivered electronically. We hand over compressed source codes, active GitHub repository ownership, credentials, and deployment documentation within 24 hours of final milestone sign-off."
        }
      ]
    },
    {
      id: "refund",
      title: "Cancellation & Refund Policy",
      icon: RefreshCw,
      shortDesc: "Refund rules, deposit returns, contract terminations, and milestone cancellations for software, computing AMC, cybersecurity services, and consulting contracts.",
      lastUpdated: "July 12, 2026",
      sections: [
        {
          heading: "1. Digital Services & Custom Software Development",
          content: "Bespoke software development, custom web portals, and mobile application engineering are executed in structured stages or milestones. Refunds are structured as follows:"
        },
        {
          heading: "2. Milestone-Based Refund Terms",
          content: [
            "Discovery & Planning Stage: If a project is cancelled by the client before any active development or coding begins, a 100% refund of the initial deposit is processed, minus any consulting hours already logged.",
            "Active Development Milestones: Once active software development, custom UI design, or database engineering begins on a milestone, payments for that active milestone are non-refundable.",
            "Delivered Software: Completed milestones that have been reviewed, approved, and signed off by the client are strictly non-refundable."
          ]
        },
        {
          heading: "3. Cybersecurity Audits & VAPT Audits",
          content: "Cybersecurity audits, network VAPT, and ethical hacking exercises require dedicated pre-allocation of security specialists and virtual sandbox preparation. Once audit activities begin or targets are queued for scanning, fees are 100% non-refundable."
        },
        {
          heading: "4. Annual Maintenance Contracts (AMC) Cancellations",
          content: "Clients may cancel their Annual Maintenance Contracts (AMC) for computers and IT support by providing a written notice at least thirty (30) days in advance to Sahil@Sidigiqor.com. In the event of AMC cancellation, refunds for the remaining unused months will be calculated pro-rata, deducting a 10% administrative cancellation charge."
        },
        {
          heading: "5. Refund Processing Timelines",
          content: "Approved refunds are processed back to the original bank account, corporate card, or payment gateway account within seven to ten (7-10) business days. Sidigiqor Technologies is not responsible for secondary bank delays."
        }
      ]
    }
  ];

  const activePolicy = policies.find(p => p.id === activePolicyId);

  return (
    <section id="legal-policies" className="py-16 bg-[#0a0a0a] border-b border-white/5 relative overflow-hidden">
      {/* Dynamic graphic lines */}
      <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-brand-gold/15 to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="h-[1px] w-6 bg-brand-gold"></span>
            <span className="text-[10px] text-brand-gold font-bold tracking-[0.2em] uppercase font-mono">08. COMPLIANCE & LEGAL</span>
            <span className="h-[1px] w-6 bg-brand-gold"></span>
          </div>
          <h2 className="font-display font-light text-2xl sm:text-3xl lg:text-4xl text-white tracking-tight uppercase leading-tight">
            Corporate <span className="font-medium italic text-brand-gold">Governance</span> & Merchant Policies
          </h2>
          <p className="text-gray-400 text-xs sm:text-sm mt-3 leading-relaxed font-medium max-w-2xl mx-auto">
            Authorized merchant frameworks and statutory legal disclosures for Sidigiqor Technologies OPC Private Limited. Tap any card below to open the complete governing policy.
          </p>
        </div>

        {/* 4 Cards Grid - Boxes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {policies.map((policy) => {
            const Icon = policy.icon;
            return (
              <button
                key={policy.id}
                onClick={() => setActivePolicyId(policy.id)}
                className="bg-[#0f0f0f] border border-white/5 hover:border-brand-gold/30 hover:bg-[#141414] rounded-sm p-5 text-left transition-all duration-300 group relative flex flex-col justify-between h-[210px] cursor-pointer shadow-xl"
              >
                {/* Visual hover border overlay */}
                <div className="absolute top-0 left-0 w-full h-[2px] bg-gradient-to-r from-brand-gold/0 via-brand-gold/30 to-brand-gold/0 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="p-2 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-xs">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="text-[8px] font-mono text-gray-500 group-hover:text-brand-gold transition-colors font-bold uppercase tracking-widest">
                      SECURE DOCUMENT
                    </span>
                  </div>

                  <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider group-hover:text-brand-gold transition-colors">
                    {policy.title}
                  </h3>

                  <p className="text-[11px] text-gray-400 leading-normal line-clamp-3 font-medium">
                    {policy.shortDesc}
                  </p>
                </div>

                <div className="flex items-center justify-between text-[10px] font-mono text-gray-500 pt-3 border-t border-white/5 w-full">
                  <span>LAST REVISED: 2026</span>
                  <span className="flex items-center gap-1 text-brand-gold font-bold uppercase tracking-wider text-[9px]">
                    Read Policy
                    <ExternalLink className="w-3 h-3 text-brand-gold/70" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Payment Gateway Compliance Footer Banner */}
        <div className="mt-8 bg-[#0c0c0c] border border-white/5 rounded-sm p-4 flex flex-col sm:flex-row items-center gap-4 justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-brand-gold/5 border border-brand-gold/10 rounded-full text-brand-gold shrink-0">
              <Info className="w-4 h-4" />
            </div>
            <p className="text-[11px] text-gray-400 font-medium leading-relaxed">
              These policies ensure absolute operational transparency, licensing safety, and 100% compliance with digital payment gateways, RBI regulations, and consumer safety charters.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <span className="text-[9px] font-mono text-gray-500 font-bold uppercase tracking-wider">
              AUTHORIZED GATEWAY MERCHANT
            </span>
            <div className="w-1.5 h-1.5 rounded-full bg-brand-gold shadow-[0_0_6px_#c5a880]"></div>
          </div>
        </div>
      </div>

      {/* Pop-up Window Modal */}
      <AnimatePresence>
        {activePolicyId && activePolicy && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop layer */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setActivePolicyId(null)}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm cursor-pointer"
            />

            {/* Modal Body container */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ duration: 0.25, ease: "easeOut" }}
              className="bg-[#0d0d0d] border border-white/10 rounded-md w-full max-w-3xl max-h-[85vh] overflow-hidden flex flex-col relative z-10 shadow-2xl"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-white/5 bg-black/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-brand-gold/10 border border-brand-gold/20 text-brand-gold rounded-xs">
                    {React.createElement(activePolicy.icon, { className: "w-4 h-4" })}
                  </div>
                  <div>
                    <h2 className="font-display font-bold text-sm sm:text-base text-white uppercase tracking-wider">
                      {activePolicy.title}
                    </h2>
                    <p className="text-[10px] font-mono text-brand-gold/80 font-bold uppercase tracking-wider">
                      Sidigiqor Corporate Policy • Last Updated: {activePolicy.lastUpdated}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setActivePolicyId(null)}
                  className="p-2 hover:bg-white/5 text-gray-400 hover:text-white rounded-full transition-colors cursor-pointer"
                  title="Close Policy Window"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body Scroll Area */}
              <div className="px-6 py-6 overflow-y-auto space-y-6 text-sm leading-relaxed text-gray-300 font-sans custom-scrollbar">
                
                {/* Top overview note */}
                <div className="bg-[#121212] border border-white/5 rounded-xs p-4 flex items-start gap-3">
                  <ShieldAlert className="w-4 h-4 text-brand-gold shrink-0 mt-0.5" />
                  <p className="text-xs text-gray-400 font-medium leading-relaxed">
                    This document serves as an active legal agreement for client operations, digital solutions delivery, and merchant accounts of **Sidigiqor Technologies OPC Private Limited**.
                  </p>
                </div>

                {activePolicy.sections.map((sec, idx) => (
                  <div key={idx} className="space-y-2 border-b border-white/5 pb-4 last:border-0 last:pb-0">
                    <h4 className="font-display font-bold text-xs sm:text-sm text-white uppercase tracking-wide flex items-center gap-2">
                      <FileCheck2 className="w-3.5 h-3.5 text-brand-gold" />
                      {sec.heading}
                    </h4>
                    
                    {Array.isArray(sec.content) ? (
                      <ul className="space-y-2.5 pl-5 list-disc text-xs text-gray-400">
                        {sec.content.map((bullet, bIdx) => {
                          const parts = bullet.split(":");
                          if (parts.length > 1) {
                            return (
                              <li key={bIdx} className="leading-relaxed font-medium">
                                <strong className="text-gray-200">{parts[0]}:</strong>{parts.slice(1).join(":")}
                              </li>
                            );
                          }
                          return (
                            <li key={bIdx} className="leading-relaxed font-medium">
                              {bullet}
                            </li>
                          );
                        })}
                      </ul>
                    ) : (
                      <p className="text-xs sm:text-sm text-gray-400 font-medium leading-relaxed pl-5">
                        {sec.content}
                      </p>
                    )}
                  </div>
                ))}
              </div>

              {/* Modal Footer */}
              <div className="px-6 py-4 border-t border-white/5 bg-black/50 flex flex-col sm:flex-row items-center justify-between gap-3">
                <span className="text-[10px] font-mono text-gray-500 font-bold uppercase tracking-widest">
                  SECURED VIA AES-256 ENCRYPTION
                </span>
                <button
                  onClick={() => setActivePolicyId(null)}
                  className="px-5 py-2 bg-brand-gold hover:bg-brand-gold/90 text-black font-display font-bold text-xs uppercase tracking-wider rounded-xs cursor-pointer transition-all w-full sm:w-auto text-center"
                >
                  Acknowledge & Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
